package com.example.team_five;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamFiveApplicationTests {

    @Test
    void contextLoads() {
    }

}
