package com.example.team_five;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamFiveApplication {

    public static void main(String[] args) {
        SpringApplication.run(TeamFiveApplication.class, args);
    }

}
