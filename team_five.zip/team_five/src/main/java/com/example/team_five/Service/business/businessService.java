package com.example.team_five.Service.business;

public interface businessService {
}
