package com.example.team_five.Service.business;

import org.springframework.stereotype.Service;

@Service
public class businessServiceImp implements businessService{
}
